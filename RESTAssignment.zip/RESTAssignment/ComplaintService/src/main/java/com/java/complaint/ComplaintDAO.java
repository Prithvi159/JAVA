package com.java.complaint;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ComplaintDAO {
	
	Connection connection;
	PreparedStatement pst;
	
	public String addComplaint(Complaint complaint) throws ClassNotFoundException, SQLException {
		
		connection = ConnectionHelper.getConnection();
		String cmd = "Insert into Complaint(ComplaintID,ComplaintType,CDescription,ComplaintDate,Severity,Status)"
				+ "values(?,?,?,?,?,?)";
		
		pst = connection.prepareStatement(cmd);
		pst.setString(1, complaint.getComplaintId());
		pst.setString(2, complaint.getComplaintType());
		pst.setString(3, complaint.getDescription());
		long d1=System.currentTimeMillis();
		java.sql.Date date=new java.sql.Date(d1);
		pst.setDate(4, date);
		pst.setString(5, complaint.getSeverity());
		pst.setString(6, "PENDING");
		pst.executeUpdate();
		
		return "Complaint Raised Successfully...";
	}
	
	public Complaint[] showComplaint() throws ClassNotFoundException, SQLException {
			
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Complaint";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Complaint> complaintList = new ArrayList<Complaint>();
		Complaint complaint = null;
		
		while(rs.next()) {
			complaint = new Complaint();
			complaint.setComplaintId(rs.getString("ComplaintID"));
			complaint.setComplaintType(rs.getString("ComplaintType"));
			complaint.setDescription(rs.getString("CDescription"));
			complaint.setComplaintDate(rs.getDate("ComplaintDate"));
			complaint.setSeverity(rs.getString("Severity"));
			complaint.setStatus(rs.getString("Status"));
			complaintList.add(complaint);
		}
		return complaintList.toArray(new Complaint[complaintList.size()]);
	}
	
	public Complaint searchComplaint(String complaintid) throws ClassNotFoundException, SQLException {
			
		connection = ConnectionHelper.getConnection();
		String cmd = "select * from Complaint where ComplaintID=?";
		pst = connection.prepareStatement(cmd);
		pst.setString(1, complaintid);
		ResultSet rs = pst.executeQuery();
		Complaint complaint = null;
		if(rs.next()) {
			complaint = new Complaint();
			complaint.setComplaintId(rs.getString("ComplaintID"));
			complaint.setComplaintType(rs.getString("ComplaintType"));
			complaint.setDescription(rs.getString("CDescription"));
			complaint.setComplaintDate(rs.getDate("ComplaintDate"));
			complaint.setSeverity(rs.getString("Severity"));
			complaint.setStatus(rs.getString("Status"));
		}
		return complaint;
	}
	
	public String check(Complaint complaint) throws ClassNotFoundException, SQLException {
		
		Connection con=ConnectionHelper.getConnection();
		String cmd="select ResolveDate from resolve where ComplaintID=?";
		PreparedStatement pst =con.prepareStatement(cmd);
		pst.setString(1, complaint.getComplaintId());
		ResultSet rs = pst.executeQuery();
		rs.next();
		Date resdate=rs.getDate("ResolveDate");
		long diff = resdate.getTime() - complaint.getComplaintDate().getTime();
		double daysBetween = (diff / (1000*60*60*24));
		int days=(int)daysBetween;
		days++;
		if(resdate.getTime()==complaint.getComplaintDate().getTime()) {
			return "green";
		} else if(days>=5) {
			return "pink";
		} else {
			return "red";
		}
		
	}
	
	public String resolve(Resolve res) throws ClassNotFoundException, SQLException {
		
		Complaint complaint = searchComplaint(res.getComplaintId());
		if(complaint!=null) {
			
			Connection con=ConnectionHelper.getConnection();
			String cmd = "insert into resolve(ComplaintID,ComplaintDate,ResolveDate,ResolvedBy,"
					+ "Comments) values(?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(cmd);
			pst.setString(1, res.getComplaintId());
			pst.setDate(2, complaint.getComplaintDate());
			long d1=System.currentTimeMillis();
			Date date = new Date(d1);
			pst.setDate(3, date);
			pst.setString(4, res.getName());
			pst.setString(5, res.getComments());
			pst.executeUpdate();
			
			cmd="Update Complaint set status='Resolved' where ComplaintID=?";
			PreparedStatement pst1 = con.prepareStatement(cmd);
			pst1.setString(1, res.getComplaintId());
			pst1.executeUpdate();
			return "Complaint raised...and Status Updated...";
			
		}
		return "Invalid ComplaintID....";
	}

}
