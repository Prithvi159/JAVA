package com.java.oyo;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table (name="Booking")
public class Booking {

	@Id
	@Column(name="bookid")
	private String bookid;
	
	@Column(name="roomid")
	private String roomid;
	
	@Column(name="custName")
	private String custName;
	
	@Column(name="city")
	private String city;
	
	@Column(name="bookDate")
	private Date bookDate;
	
	@Column(name="chkInDate")
	private Date chkInDate;
	
	@Column(name="chkOutDate")
	private Date chkOutDate;
	
	
	public String getBookid() {
		return bookid;
	}
	public void setBookid(String bookid) {
		this.bookid = bookid;
	}
	public String getRoomid() {
		return roomid;
	}
	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Date getBookDate() {
		return bookDate;
	}
	public void setBookDate(Date bookDate) {
		this.bookDate = bookDate;
	}
	public Date getChkInDate() {
		return chkInDate;
	}
	public void setChkInDate(Date chkInDate) {
		this.chkInDate = chkInDate;
	}
	public Date getChkOutDate() {
		return chkOutDate;
	}
	public void setChkOutDate(Date chkOutDate) {
		this.chkOutDate = chkOutDate;
	}
	
	
}
