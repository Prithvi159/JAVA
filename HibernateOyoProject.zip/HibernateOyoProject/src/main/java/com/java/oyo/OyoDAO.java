package com.java.oyo;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;



public class OyoDAO {
	
	static SessionFactory sf;
	static Session session;
	static Query query;
	
	static {
		sf = SessionHelper.getFactory();
		session = sf.openSession();
	}

	public String generateRoomId() {
		query = session.createQuery(" from Room");
		List<Room> lst = query.list();
		
		if(lst.isEmpty()) {
			return "R000";
		} else {
			Room r = lst.get(lst.size()-1);
			String rid = r.getRoomid();
			int id =Integer.parseInt(rid.substring(1));
			id++;
			if (id >=1 && id <= 9) {
				rid = "R00"+id;
			}
			if (id >= 10 && id <= 99) {
				rid="R0"+id;
			}
			if (id >= 100 && id <= 999) {
				rid="R"+id;
			}
			return rid;
		}
	}
	
	public String generateBookId() {
		query = session.createQuery("from Booking");
		List<Booking> lst = query.list();
		
		if(lst.isEmpty()) {
			return "B000";
		} else {
			Booking b = lst.get(lst.size()-1);
			String bid=b.getBookid();
			int id =Integer.parseInt(bid.substring(1));
			id++;
			if (id >=1 && id <=9) {
				bid = "B00"+id;
			}
			if (id >=10 && id <=99) {
				bid="B0"+id;
			}
			if (id >=100 && id <= 999) {
				bid="B"+id;
			}
			return bid;
		}
	}
	
	//ADD ROOM
	public void addRoom(Room room) {
		Transaction t = session.beginTransaction();
		session.save(room);
		t.commit();
	}
	
	//ROOM AVAILABILITY
	public List<Room> showAvailRoom() {
		query = session.createQuery("from Room where status='AVAILABLE' ");
		List<Room> lst = query.list();
		
		if(lst.isEmpty()) {
			return null;
		} else {
			return lst;
		}
	}
	
	//BOOKING ROOM
	public void booking(Booking book, String roomid) {
		Transaction t = session.beginTransaction();
		session.save(book);
		t.commit();
		
		query = session.createQuery("from Room where roomId = '"+roomid+"' ");
		List<Room> lst = query.list();
		Room r = lst.get(0);
		Transaction t2 = session.beginTransaction();
		r.setStatus(Status.BOOKED);
		session.save(r);
		t2.commit();
	}
	
}
