package com.java.oyo;

public enum Status {
	AVAILABLE,BOOKED
}
