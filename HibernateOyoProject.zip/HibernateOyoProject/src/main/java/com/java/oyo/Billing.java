package com.java.oyo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="Billing")
public class Billing {
	
	
	@Id
	@Column(name="BillID")
	private int billid;
	
	@Column(name="bookid")
	private String bookid;
	
	@Column(name="roomid")
	private String roomid;
	
	@Column(name="noOfDays")
	private int noOfDays;
	
	@Column(name="billAmt")
	private int billAmt;

	public int getBillid() {
		return billid;
	}

	public void setBillid(int billid) {
		this.billid = billid;
	}

	public String getBookid() {
		return bookid;
	}

	public void setBookid(String bookid) {
		this.bookid = bookid;
	}

	public String getRoomid() {
		return roomid;
	}

	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}

	public int getBillAmt() {
		return billAmt;
	}

	public void setBillAmt(int billAmt) {
		this.billAmt = billAmt;
	}
	

}
