package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class LeaveService {

	@Autowired
	private LeaveRepository repo;
	@Autowired
	private EmployRepository emprepo;
	@Autowired
	private LeaveDetailsDAO dao;
	
	public Leave search(int leaveId) {
		return repo.findById(leaveId).get();
	}
	
	public List<Leave> showEmployHistory(int empId){
		return dao.leaveHistory(empId);
	}
	
	public List<Leave> showPendingLeaves(int empId) {
		return dao.pendingLeaves(empId);
	}
	
	//LEAVE APPLY
	public String applyLeave(Leave leave) {
		Employ emp = emprepo.findById(leave.getEmpId()).get();
		int availLeave = emp.getLeaveAvail();
		
		if(availLeave >= leave.getNoOfDays()) {
			repo.save(leave);
			dao.updateEmployApprove(leave.getNoOfDays());
			return "Leave Applied...";
		}
		return "Insufficient leaves available..";
	}
	
	//APPROVE DENY 
	public String approveDeny(int lid,int mid,String status,String comments) {
		Leave leave = repo.findById(lid).get();
		Employ emp = emprepo.findById(leave.getEmpId()).get();
		
		if (mid!=emp.getMgrId()) {
			return "You are unauthorized manager...";
		} 
		if (status.toUpperCase().equals("YES")) {
			return dao.updateStatus(lid,"APPROVED",comments);
		} else {
			dao.updateEmployDeny(leave.getNoOfDays());
			return dao.updateStatus(lid,"DENIED",comments);				
		}
	}
	
}
