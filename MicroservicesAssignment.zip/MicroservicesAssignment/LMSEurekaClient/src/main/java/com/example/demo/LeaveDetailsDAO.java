package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class LeaveDetailsDAO {
	
	@Autowired  
    JdbcTemplate jdbc;  
	
	//EMPLOY PENDING LEAVES
	public List<Leave> pendingLeaves(int empId) {
		String cmd = "select * from LEAVE_HISTORY where EMP_ID = ? and Leave_Status='PENDING'";
		List<Leave> leaveList = null;
		leaveList = jdbc.query(cmd, new Object[] {empId}, new RowMapper<Leave>() {

			@Override
			public Leave mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				Leave leave = new Leave();
				leave.setLeaveId(rs.getInt(rs.getInt("LEAVE_ID")));
				leave.setNoOfDays(rs.getInt("NO_OF_DAYS"));
				leave.setManagerComments(rs.getString("MANAGER_COMMENTS"));
				leave.setEmpId(rs.getInt("EMP_ID"));
				leave.setLeaveStartDate(rs.getDate("LEAVE_START_DATE"));
				leave.setLeaveEndDate(rs.getDate("LEAVE_END_DATE"));
				leave.setLeaveStatus(rs.getString("LEAVE_STATUS"));
				leave.setLeaveType(rs.getString("LEAVE_TYPE"));
				leave.setLeaveReason(rs.getString("LEAVE_REASON"));
				return leave;
			}
		});
		return leaveList;
	}
	
	//EMPLOY LEAVE HISTORY
	public List<Leave> leaveHistory(int empId) {
		String cmd = "select * from LEAVE_HISTORY where EMP_ID = ?";
		List<Leave> leaveList = null;
		leaveList = jdbc.query(cmd, new Object[] {empId}, new RowMapper<Leave>() {

			@Override
			public Leave mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				Leave leave = new Leave();
				leave.setLeaveId(rs.getInt(rs.getInt("LEAVE_ID")));
				leave.setNoOfDays(rs.getInt("NO_OF_DAYS"));
				leave.setManagerComments(rs.getString("MANAGER_COMMENTS"));
				leave.setEmpId(rs.getInt("EMP_ID"));
				leave.setLeaveStartDate(rs.getDate("LEAVE_START_DATE"));
				leave.setLeaveEndDate(rs.getDate("LEAVE_END_DATE"));
				leave.setLeaveStatus(rs.getString("LEAVE_STATUS"));
				leave.setLeaveType(rs.getString("LEAVE_TYPE"));
				leave.setLeaveReason(rs.getString("LEAVE_REASON"));
				return leave;
			}
		});
		return leaveList;
	}
	
	public String updateStatus(int lid,String status,String comments) {
		String cmd = "Update leave_history set LEAVE_STATUS=? AND MANAGER_COMMENTS WHERE LEAVE_ID=?";
		jdbc.update(cmd, new Object[] {status,comments,lid});
		return "Leave updated";
	}
	
	public void updateEmployApprove(int days) {
		String cmd = "update Employee set LEAVE_AVAIL=LEAVE_AVAIL-?";
		jdbc.update(cmd,new Object[] {days});
	}
	
	public void updateEmployDeny(int days) {
		String cmd = "Update Employee set LEAVE_AVAIL=LEAVE_AVAIL + ?";
		jdbc.update(cmd,new Object[] {days});
	}
	
}
