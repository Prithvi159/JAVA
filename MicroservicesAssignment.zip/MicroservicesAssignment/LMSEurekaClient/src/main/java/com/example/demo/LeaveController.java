package com.example.demo;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LeaveController {
	
	@Autowired
	private LeaveService service;
	
	@RequestMapping("/leaveHistory/{eid}")
	public List<Leave> get(@PathVariable Integer eid) {
		return service.showEmployHistory(eid);
	}
	
	@RequestMapping(value="/pendingLeaves/{eid}")
	public List<Leave> employPendingLeaves(@PathVariable int eid) {
		return service.showPendingLeaves(eid);
	}
	
	@RequestMapping("/showLeave/{lid}")
	public ResponseEntity<Leave> search(@PathVariable int lid){
		try {
			Leave leave = service.search(lid);
			return new ResponseEntity<Leave>(leave,HttpStatus.OK);
		} catch(NoSuchElementException e) {
			return new ResponseEntity<Leave>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/applyLeave")
	public String applyLeave(@RequestBody Leave leave) {
		return service.applyLeave(leave);
	}
	
	@PostMapping("/approveDeny/{lid}/{mid}/{status}/{comments}")
	public String acceptOrReject(@PathVariable int lid,@PathVariable int mid, 
			@PathVariable String status,@PathVariable String comments) {
		return service.approveDeny(lid, mid, status, comments);
	}

}
